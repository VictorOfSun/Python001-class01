from django.apps import AppConfig


class DoubanConfig(AppConfig):
    name = 'Douban'
