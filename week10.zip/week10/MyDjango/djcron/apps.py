from django.apps import AppConfig


class DjcronConfig(AppConfig):
    name = 'djcron'
