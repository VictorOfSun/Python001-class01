from MyDjango.celery import app
import subprocess
# redis-server.exe redis.windows.conf


@app.task()
def get_task():
    return 'test'


@app.task()
def get_task2():
    return 'test2'


@app.task()
def get_scrapy_task():
    res = subprocess.run('cd ../../../1_scrapy/spiders && scrapy crawl phone')
    if res.returncode == 0:
        return 'scrapy ok'
    else:
        return 'no ok'

