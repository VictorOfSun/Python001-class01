from sqlalchemy import create_engine

engine = create_engine('root://@127.0.0.1:3306/test', echo=True)

sql = "select * from soda"
df1 = pd.read_sql(sql, engine)